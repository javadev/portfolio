$(function(){
	//scroll to target hash alement
	var smoothScroll = function(target, speed){
		var $target = $(target);
		this.speed = speed || 300;
		$('html, body').stop().animate({
				'scrollTop': $target.offset().top,
				queue: false
			}, this.speed, 'linear', function () {
				window.location.hash = target;
			});
	}
	var hashes = new Array();
	$('nav a[href^="#"]').each(function (index,element){
		hashes[index] = {
			offset: $(element.hash).offset().top,
			pos: element.hash
		}
	});
	$('nav a[href^="#"]').on('click',function(){
		$('nav a[href^="#"]').removeClass('selected');
		$(this).addClass('selected');
	});
	$(window).on('scroll',function(){
		console.log(hashes);
		for (var i = hashes.length-1; i>=0;i--){
			/*console.log('offset '+i+':'+hashes[i].offset);
			console.log('top '+':'+$(this).scrollTop())*/
			if($(this).scrollTop() >= hashes[i].offset){
				console.log(hashes[i].pos);
				$('nav a[href^="#"]').removeClass('selected');
				$('nav a[href^="'+hashes[i].pos+'"]').addClass('selected');
				//window.location.hash = hashes[i].pos;
				break;
			}
		}
	});

	//binding scroll to hash-links
	$('a[href^="#"]').on('click.smoothscroll',function (e) {
			e.preventDefault();		
			//$(window).off('scroll'); 
			var target = this.hash;		
		 	smoothScroll(target);
			
		});

})

