var app = angular.module('board', []);

app.controller('orderForm', function ($scope) {
  $scope.user = {};
  $scope.you = function(){
  	alert('you');
  }
});
app.controller('botForm', function ($scope) {
  $scope.user = {};
  $scope.you = function(){
    alert('you');
  }
});
  
$(document).on('click',function (e) {
	if($(e.target).parents('#popup').length) return;
	$('#popup').hide();
})
$('form input').on('focus',function(){
  console.log('asas');
  $(this).closest('.star').animate({left:"285px",queue: false})
})